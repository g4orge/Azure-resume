using System.Net;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Azure.Cosmos;
using Newtonsoft.Json;
using System;

namespace Company.Function
{
    public class GetResumeCounter
    {
        private readonly ILogger _logger;
        private readonly CosmosClient _cosmosClient;
        private readonly string _containerName = "Counter";
        private readonly string _databaseName = "AzureResume";

        public GetResumeCounter(ILoggerFactory loggerFactory)
        {
            _logger = loggerFactory.CreateLogger<GetResumeCounter>();

            var connectionString = Environment.GetEnvironmentVariable("AzureResumeConnectionString");
            _cosmosClient = new CosmosClient(connectionString);
        }

        [Function("GetResumeCounter")]
        public async Task<HttpResponseData> Run(
            [HttpTrigger(AuthorizationLevel.Function, "get", "post")] HttpRequestData req)
        {
            var container = _cosmosClient.GetContainer(_databaseName, _containerName);

            const string id = "1";
            const string partitionKey = "1";
            Counter counter;

            try
            {
                var response = await container.ReadItemAsync<Counter>(id, new PartitionKey(partitionKey));
                counter = response.Resource;
            }
            catch (CosmosException ex) when (ex.StatusCode == HttpStatusCode.NotFound)
            {
                counter = new Counter { id = id, Count = 0 };
                await container.CreateItemAsync(counter, new PartitionKey(partitionKey));
            }

            // increment and update
            counter.Count += 1;
            await container.UpsertItemAsync(counter, new PartitionKey(partitionKey));

            _logger.LogInformation($"Returning count: {counter.Count}"); // ✅ moved here

            // build response
            var responseData = req.CreateResponse(HttpStatusCode.OK);
            responseData.Headers.Add("Content-Type", "application/json");
            await responseData.WriteStringAsync(JsonConvert.SerializeObject(counter), Encoding.UTF8);

            return responseData;
        }
    }
}